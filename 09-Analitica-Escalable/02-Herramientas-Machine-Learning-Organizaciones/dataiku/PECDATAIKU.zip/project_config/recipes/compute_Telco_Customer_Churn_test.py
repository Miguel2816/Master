# -*- coding: utf-8 -*-
import dataiku
import pandas as pd, numpy as np
from dataiku import pandasutils as pdu

# Read recipe inputs
telco_Customer_Churn_prepared = dataiku.Dataset("Telco_Customer_Churn_prepared")
telco_Customer_Churn_prepared_df = telco_Customer_Churn_prepared.get_dataframe()


# Compute recipe outputs
# TODO: Write here your actual code that computes the outputs
# NB: DSS supports several kinds of APIs for reading and writing data. Please see doc.

telco_Customer_Churn_train_df = telco_Customer_Churn_prepared_df.sample(frac=0.85, random_state=42)
telco_Customer_Churn_test_df = telco_Customer_Churn_prepared_df.drop(telco_Customer_Churn_train_df.index)

# Write recipe outputs
telco_Customer_Churn_test = dataiku.Dataset("Telco_Customer_Churn_test")
telco_Customer_Churn_test.write_with_schema(telco_Customer_Churn_test_df)
telco_Customer_Churn_train = dataiku.Dataset("Telco_Customer_Churn_train")
telco_Customer_Churn_train.write_with_schema(telco_Customer_Churn_train_df)
